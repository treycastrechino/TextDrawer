import java.util.*;
/**
 * This class stores what every line of each letter looks like.
 * Each letter has a formula to follow for any given line
 * at any size. 
 * It tells java how to draw letters
 *
 *
 */
public class Alphabet
{
    public void filler(int line,int size){
        for(int i =1; i<=size;i++){
            System.out.print("_");
        }
    }

    public void space(int line,int size){
        for (int i=1;i<size;i++){
            System.out.print(" ");
        }
        System.out.print(" ");
    }

    public void a(int line, int size){
        for (int i=1;i<size;i++){
            if (line<(size/2) && line !=1){
                if (i==(size/2)+line ||i==((size/2)-line)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line==1){
                if(i==(size/2)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line>(size/2)){
                if(i==1 || i==size-1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line==(size/2)){
                System.out.print("#");
            }
        }
        System.out.print(" ");
    }

    public void b(int line,int size){
        for(int i=1;i<size;i++){
            if(line==1 || line==(size/2) || line==(size-1)){
                if(i!=size-1){System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            else{
                if(i==1 || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void c(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1 || line==size-1){
                System.out.print("#");
            }
            else{
                if(i==1){
                    System.out.print("#");
                }
                if(i!=1){
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void d(int line,int size){
        for(int i=1;i<size;i++){
            if(line==1 || line==size-1){
                if(i==size-1){
                    System.out.print(" ");
                }
                else{
                    System.out.print("#");
                }
            }
            else{
                if(i==1 || i==size-1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void e(int line,int size){
        for (int i=1;i<size;i++){
            if (line == 1 || line==(size/2) || line==(size-1)){
                System.out.print("#");
            }
            else{
                if(i==1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void f(int line,int size){
        for (int i=1;i<size;i++){
            if (line == 1){
                System.out.print("#");
            }
            if (line==(size/2)) {
                System.out.print("#");
            }
            if(line!=1 && line!=(size/2)){
                if(i==1){
                    System.out.print("#");

                }
                else{
                    System.out.print(" ");
                }

            }

        }
        System.out.print(" ");
    }

    public void g(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1 || line==(size-1)){
                System.out.print("#");
            }
            if(line==(size/2)){
                if(i>=(size/2) || i==1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line<(size/2) && line!=1){
                if(i==1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line>(size/2) && line!=(size-1)){
                if(i==1 || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void h(int line,int size){
        for(int i=1;i<size;i++){
            if(line==(size/2)){
                System.out.print("#");
            }
            else{
                if(i==1 || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void i(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1 || line==(size-1)){
                System.out.print("#");
            }
            else{
                if(i==(size/2)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void j(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1){
                System.out.print("#");
            }
            if(line>=(size/2) && line!=(size-1)){
                if(i==1 || i==(size/2)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line<(size/2) && line!=1){
                if(i==(size/2)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line==(size-1)){
                if(i<=(size/2)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void k(int line,int size){
        for (int i=1;i<size;i++){
            if(i==1){
                System.out.print("#");
            }
            if(line<(size/2)){
                if(i==((size/2)-line)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line>(size/2)){
                if(i==(line-(size/2))){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line==(size/2)){
                if(i==1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void l(int line, int size){
        for (int i=1;i<size;i++){
            if(line==(size-1)){
                System.out.print("#");
            }
            else{
                if(i==1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void m(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1){
                if(i==1 || i==(size/2) || i==(size-1)){
                    System.out.print(" ");
                }
                else{
                    System.out.print("#");
                }
            }
            if(line!=1){
                if(i==1 || i==(size/2) || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void n(int line,int size){
        for (int i=1;i<size;i++){

            if(i==line || i==1 || i==(size-1)){
                System.out.print("#");
            }
            else{
                System.out.print(" ");
            }

        }
        System.out.print(" ");
    }

    public void o(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1 || line==(size-1)){
                System.out.print("#");
            }
            else{
                if(i==1 || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void p(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1 || line==(size/2)){
                System.out.print("#");
            }
            if(line<(size/2) && line!=1 ){
                if(i==1 || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line>(size/2)){
                if(i==1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void q(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1 || line==(size-1)){
                System.out.print("#");
            }
            else{
                if(line<=(size/2) && line!=1){
                    if(i==1 || i==(size-1)){
                        System.out.print("#");
                    }
                    else{
                        System.out.print(" ");
                    }
                }
                if(line>(size/2) && line!=(size-1)){
                    if(i==(line-1) || i==1 || i==(size-1)){
                        System.out.print("#");
                    }
                    else{
                        System.out.print(" ");
                    }   
                }
            }

        }
        System.out.print(" ");
    }

    public void r(int line,int size){
        for (int i=1;i<size;i++){
            if (line == 1 || line==(size/2)){
                if(i==(size-1)){
                    System.out.print(" ");
                }
                else{
                    System.out.print("#");
                }
            }

            if(line!=1 && line<(size/2)){
                if(i==1 || i==size-1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line>(size/2)){
                if(i==1 || i==((size/2)+(line-(size/2)))){
                    System.out.print("#");
                }

                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void s(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1){
                if(i!=1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line==(size/2)){
                if(i==1 || i==(size-1)){
                    System.out.print(" ");
                }
                else{
                    System.out.print("#");
                }
            }
            if(line==(size-1)){
                if(i==(size-1)){
                    System.out.print(" ");
                }
                else{
                    System.out.print("#");
                }
            }
            if(line>(size/2) && line!=(size-1)){
                if(i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line<(size/2) && line!=1){
                if(i==1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void t(int line,int size){
        for (int i=1;i<size;i++){
            if (line == 1){
                System.out.print("#");
            }
            else{
                if(i==(size/2)){
                    System.out.print("#");

                }
                else{
                    System.out.print(" ");
                }

            }
        }
        System.out.print(" ");
    }

    public void u(int line,int size){
        for (int i=1;i<size;i++){
            if(line!=(size-1)){
                if(i==1 || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            else{
                System.out.print("#");
            }
        }
        System.out.print(" ");
    }

    public void v(int line,int size){
        for (int i=1;i<size;i++){
            if(line<(size/2)){
                if(i==1 || i==(size-1) || i==(size/2)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line==(size/2)){
                if(i==1 || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line>(size/2)){
                if(i==(1+(line-(size/2))) || i==(size-1)-(line-(size/2))){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void w(int line,int size){
        for (int i=1;i<size;i++){
            if(line!=(size-1)){
                if(i==1 || i==(size/2) || i==(size-1)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            else{
                if(i==1 || i==(size-1)){
                    System.out.print(" ");
                }
                else{
                    System.out.print("#");
                }
            }
        }
        System.out.print(" ");
    }

    public void x(int line,int size){
        for (int i=1;i<size;i++){
            if(i==line || i==(size)-line){
                System.out.print("#");
            }
            else{
                System.out.print(" ");
            }
        }
        System.out.print(" ");
    }

    public void y(int line, int size){
        for (int i=1;i<size;i++){
            if (line<(size/2)){
                if(i==line || i==(size-line)){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
                    
            }
            if (line==(size/2)){
                if (i==(size/2)){
                    System.out.print("#");
                }
                if (i!=(size/2)){
                    System.out.print(" ");
                }
            }
            if (line>(size/2)){
                if (i==(size/2)){
                    System.out.print("#");
                }
                if (i!=(size/2)){
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }

    public void z(int line,int size){
        for (int i=1;i<size;i++){
            if(line==1 || line==(size-1)){
                System.out.print("#");
            }
            else{
                if(i==(size-1)-line){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
        System.out.print(" ");
    }
    public void ex(int line,int size){
       for(int i=1;i<size;i++){
           if(line!=size-2){
               if(i==size/2){
                   System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line==size-2){
                System.out.print(" ");
            }
       } 
    }
    public void qu(int line,int size){
        for(int i=1;i<size;i++){
            if(line==1){
                System.out.print("#");
            }
            if(line==size-2){
                System.out.print(" ");
            }
            if(line==size-1){
                if(i==size/2){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line==size/2){
                if(i>=size/2){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line<size/2 && line!=1){
                if(i==size-1){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
            if(line>size/2 && line!=size-1 && line!=size-2){
                if(i==size/2){
                    System.out.print("#");
                }
                else{
                    System.out.print(" ");
                }
            }
        }
    }
} 

