import java.util.*;
/**
 * This is the main method that runs the letters you want.
 * The entire program is supposed to ask you for a word
 * or sentence and print it to the screen.
 *
 *
 */
public class Main
{
    public static void main(){
    // this initializes later variables
    int text[];
    String userInput;
    //this enter is to avoid the bluej indent bug.
    System.out.println();
    //this imports all our letter methods
    Scanner in = new Scanner(System.in);
    AlphabetNumber number = new AlphabetNumber();
    Alphabet letter = new Alphabet();
    LetterConverter c = new LetterConverter();
    
    
    //this sets the size of each letter's box
    int size = 12;
    System.out.println("Welcome to Text Drawer!");
    System.out.print("I am going to ask you for some ");
    System.out.print("some information. Then draw you ");
    System.out.println("words in cool text!");
    //Now the user is prompted for the sentence
    System.out.print("Now give me the sentance!");
    // this saves the users sentence
    userInput=in.nextLine();
    // this convertes the sentence into all the individual characters
    char[] charArray= userInput.toCharArray();
    // this tells the int array how long the users sentence is
    text= new int[charArray.length];
    // this creates a string array that will hold the chars
    // as strings so they can be turned into numbers
    String[] textArray= new String[charArray.length];
    // this loop sets all our strings from the char array
    for(int i=0;i<charArray.length;i++){
        String hold;
        hold = Character.toString(charArray[i]);
        textArray[i]=hold;
        
    }
    // this loop sets all our strings into values we can use to call drawers
    for(int i=0;i<textArray.length;i++){
        text[i]=c.convert(textArray[i]);
    }
    // this loop draws the first row of dead space then
    // prints a line to continue drawing the letters
    for (int i=0;i<=textArray.length;i++){
        if (i<textArray.length){
            letter.filler(size,size);
        }
       
    } 
    // this is just a line skip outside the loop to prepare for the letters
    System.out.println("_");
    /**
     * this loop series draws the letters one by one
     * based on what line the loop is at. When it is at 1
     * it knows to draw whatever "letter" line 1 looks
     * like. The length loop tells it to draw to the right
     * however many letters are in our word then 
     * print a new line and repeat for subsequent lines. 
     */
    for (int line=1;line<size;line++){    
    for (int i=0;i<textArray.length;i++){
    number.getNumber(text[i],line,size);
    }
    System.out.println();
    }
    // this is the closing line that makes the letters look neat
    for (int i=0;i<=textArray.length;i++){
        if (i<textArray.length){
            letter.filler(size,size);}
    } 
    System.out.println("_");
}
}
