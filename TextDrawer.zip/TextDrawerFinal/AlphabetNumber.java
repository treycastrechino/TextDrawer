import java.util.*;
/**
 * This gives each letter in the alphabet a numerical value
 * that can be called to find out which formula to use.
 *
 * 
 */
public class AlphabetNumber
{
    Alphabet get = new Alphabet();
    public void getNumber(int location,int line, int size){
        if (location == 0){
            get.space(line,size);
        } 
        if (location == 1){
            get.a(line,size); 
        }
        if (location == 2){
            get.b(line,size); 
        }
        if (location == 3){
            get.c(line,size); 
        }
        if (location == 4){
            get.d(line,size); 
        }
        if (location == 5){
            get.e(line,size);
        }
        if (location == 6){
            get.f(line,size); 
        }
        if (location == 7){
            get.g(line,size); 
        }
        if (location == 8){
            get.h(line,size); 
        }
        if (location == 9){
            get.i(line,size); 
        }
        if (location == 10){
            get.j(line,size); 
        }
        if (location == 11){
            get.k(line,size); 
        }
        if (location == 12){
            get.l(line,size); 
        }
        if (location == 13){
            get.m(line,size); 
        }
        if (location == 14){
            get.n(line,size); 
        }
        if (location == 15){
            get.o(line,size); 
        }
        if (location == 16){
            get.p(line,size); 
        }
        if (location == 17){
            get.q(line,size); 
        }
        if (location == 18){
            get.r(line,size);
        }
        if (location == 19){
            get.s(line,size); 
        }
        if (location == 20){
            get.t(line,size);
        }
        if (location == 21){
            get.u(line,size); 
        }
        if (location == 22){
            get.v(line,size); 
        }
        if (location == 23){
            get.w(line,size); 
        }
        if (location == 24){
            get.x(line,size); 
        }
        if (location == 25){
            get.y(line,size);
        }
        if (location == 26){
            get.z(line,size); 
        }
        if (location == 27){
            get.ex(line,size);
        }
        if(location == 28){
            get.qu(line,size);
        }
    }
}
