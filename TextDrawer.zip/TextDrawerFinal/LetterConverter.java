
/**
 * This method turns the string that the user inputs
 * into a numerical representation for each letter or
 * an empty space.
 *
 *
 */
public class LetterConverter
{
    public int convert(String letter){
        int x=0;
        if(letter.equals("-")){
            x=0;
        }
        if(letter.equals("a") || letter.equals("A")){
           x=1; 
        }
        if(letter.equals("b") || letter.equals("B")){
           x=2; 
        }
        if(letter.equals("c") || letter.equals("C")){
           x=3; 
        }
        if(letter.equals("d") || letter.equals("D")){
           x=4; 
        }
        if(letter.equals("e") || letter.equals("E")){
           x=5; 
        }
        if(letter.equals("f") || letter.equals("F")){
           x=6; 
        }
        if(letter.equals("g") || letter.equals("G")){
           x=7; 
        }
        if(letter.equals("h") || letter.equals("H")){
           x=8; 
        }
        if(letter.equals("i") || letter.equals("I")){
           x=9; 
        }
        if(letter.equals("j") || letter.equals("J")){
           x=10; 
        }
        if(letter.equals("k") || letter.equals("K")){
           x=11; 
        }
        if(letter.equals("l") || letter.equals("L")){
           x=12; 
        }
        if(letter.equals("m") || letter.equals("M")){
           x=13; 
        }
        if(letter.equals("n") || letter.equals("N")){
           x=14; 
        }if(letter.equals("o") || letter.equals("O")){
           x=15; 
        }
        if(letter.equals("p") || letter.equals("P")){
           x=16; 
        }
        if(letter.equals("q") || letter.equals("Q")){
           x=17; 
        }
        if(letter.equals("r") || letter.equals("r")){
           x=18; 
        }
        if(letter.equals("s") || letter.equals("S")){
           x=19; 
        }
        if(letter.equals("t") || letter.equals("T")){
           x=20; 
        }
        if(letter.equals("u") || letter.equals("U")){
           x=21; 
        }
        if(letter.equals("v") || letter.equals("V")){
           x=22; 
        }
        if(letter.equals("w") || letter.equals("W")){
           x=23; 
        }
        if(letter.equals("x") || letter.equals("X")){
           x=24; 
        }
        if(letter.equals("y") || letter.equals("Y")){
           x=25; 
        }
        if(letter.equals("z") || letter.equals("Z")){
           x=26; 
        }
        if(letter.equals("!")){
            x=27;
        }
        if(letter.equals("?")){
            x=28;
        }
        return x;
    }
}
